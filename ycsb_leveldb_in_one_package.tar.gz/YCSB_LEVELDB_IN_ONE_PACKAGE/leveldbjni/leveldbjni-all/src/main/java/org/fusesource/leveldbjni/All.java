package org.fusesource.leveldbjni;

public class All {
}